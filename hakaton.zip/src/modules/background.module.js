import {Module} from '../core/module'

export class BackgroundModule extends Module {

}