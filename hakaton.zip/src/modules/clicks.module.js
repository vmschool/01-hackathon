import {Module} from '../core/module'

export class ClicksModule extends Module {

}